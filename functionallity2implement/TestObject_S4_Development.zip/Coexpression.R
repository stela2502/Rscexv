source('libs/Tool_Coexpression.R')
load('analysis.RData')
t <- coexpressGenes(data)
write.table(t,'Coexpression_4_Cytoscape.txt',row.names=F, sep=' ')