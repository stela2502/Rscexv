source('libs/Tool_Plot.R')
source('libs/Tool_Coexpression.R')
source('libs/Tool_grouping.R')
source('libs/beanplot_mod/beanplotbeanlines.R')
source('libs/beanplot_mod/beanplot.R')
source('libs/beanplot_mod/getgroupsfromarguments.R')
source('libs/beanplot_mod/beanplotinnerborders.R')
source('libs/beanplot_mod/beanplotscatters.R')
source('libs/beanplot_mod/makecombinedname.R')
source('libs/beanplot_mod/beanplotpolyshapes.R')
source('libs/beanplot_mod/fixcolorvector.R')
source('libs/beanplot_mod/seemslog.R')
load( 'norm_data.RData')
source ('libs/Tool_RandomForest.R')
load('RandomForestdistRFobject_genes.RData')
createGeneGroups_randomForest (data.filtered, 10)
source ('Gene_grouping.randomForest.txt')
source ('Grouping.randomForest.n8.txt')
groups.n <-length (levels(as.factor(userGroups$groupID) ))
 move.neg <- TRUE
plot.neg <- TRUE
beanplots = TRUE
plotsvg = 0
zscoredVioplot = 1
onwhat='Expression'
data <- analyse.data ( data.filtered, groups.n=groups.n,  onwhat='Expression', clusterby='MDS', mds.type='PCA', cmethod='ward.D', LLEK='2',  ctype= 'hierarchical clust',  zscoredVioplot = zscoredVioplot, move.neg = move.neg, plot.neg=plot.neg, beanplots=beanplots)

save( data, file='analysis.RData' )

GOI <- NULL
try( GOI <- get.GOI( data$z$PCR, data$clusters, exclude= -20 ), silent=T)
if ( ! is.null(data$PCR) && ! is.null(GOI) ) {
    rbind( GOI, get.GOI( data$z$PCR, data$clusters, exclude= -20 ) ) 
}
write.table( GOI, file='GOI.xls' )

write.table( cbind( Samples = rownames(data$PCR), data$PCR ), file='merged_data_Table.xls' , row.names=F, sep='	',quote=F )
if ( ! is.null(data$FACS)){
write.table( cbind( Samples = rownames(data$FACS), data$FACS ), file='merged_FACS_Table.xls' , row.names=F, sep='	',quote=F )
all.data <- cbind(data$PCR, data$FACS )
write.table(cbind( Samples = rownames(all.data), all.data ), file='merged_data_Table.xls' , row.names=F, sep='	',quote=F )
}
write.table( cbind( Samples = rownames(data$mds.coord), data$mds.coord ), file='merged_mdsCoord.xls' , row.names=F, sep='	',quote=F )

## the lists in one file

write.table( cbind( Samples = rownames(data$PCR), ArrayID = data$ArrayID, Cluster =  data$clusters, 'color.[rgb]' =  data$colors ),
		file='Sample_Colors.xls' , row.names=F, sep='	',quote=F )
write.table( cbind( Samples = rownames(data$PCR),ArrayID = data$ArrayID, Cluster =  data$clusters, 'color.[rgb]' =  data$colors, data$PCR ),
		file='Selected_PCR_data_normlized.xls' , row.names=F, sep='	',quote=F )
