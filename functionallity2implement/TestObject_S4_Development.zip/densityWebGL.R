options(rgl.useNULL=TRUE)
library(ks)
load( 'clusters.RData' )
usable <- is.na(match( obj$clusters, which(table(as.factor(obj$clusters)) < 4 ) )) == T
use <- obj
use$clusters <- obj$clusters[usable]
use$mds.coord <- obj$mds.coord[usable,]
cols <- rainbow(max(as.numeric(obj$clusters)))
H <- Hkda( use$mds.coord, use$clusters, bw='plugin')
kda.fhat <- kda( use$mds.coord, use$clusters,Hs=H, compute.cont=TRUE)
try(plot(kda.fhat, size=0.001, colors = cols[as.numeric(names(table(use$clusters)))] ),silent=F)
try( writeWebGL(dir = 'densityWebGL', width=470, height=470, prefix='K', template='libs/densityWebGL.html' ) ,silent=F )
