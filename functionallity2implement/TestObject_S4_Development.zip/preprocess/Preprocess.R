source ('../libs/Tool_Pipe.R')
source ('../libs/Tool_Plot.R')
negContrGenes <- NULL
plotsvg = 0
data.filtered <- createDataObj ( PCR= c( '../PCR_Array1.csv.mod', '../PCR_Array2.csv.mod', '../PCR_Array3.csv.mod' ),  PCR2= NULL, FACS= c( '../Array1_Index_sort.csv.mod','../Index_sort_Array2.csv.mod','../Index_sort_Array3.csv.mod' ), ref.genes= NULL, use_pass_fail = 'True', max.value=40, max.ct= 25 , max.control=0,  norm.function='none', negContrGenes=negContrGenes )
save( data.filtered, file='../norm_data.RData' )
