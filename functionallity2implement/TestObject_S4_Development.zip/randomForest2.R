## this is using work published in
## Tao Shi and Steve Horvath (2006) Unsupervised Learning with Random Forest Predictors. 
## Journal of Computational and Graphical Statistics. Volume 15, Number 1, March 2006, pp. 118-138(21)
initial.options <- commandArgs(trailingOnly = FALSE)
script.dir <- dirname ( initial.options[ grep( 'randomForest', initial.options ) ] )
print ( paste( 'working directory = ',script.dir))
setwd(script.dir)
lock.name <- 'randomForest_worker_NUMBER.Rdata'
lock.name2 <- 'randomForest_worker_genes_NUMBER.Rdata'
source ('libs/Tool_RandomForest.R')
source ('libs/Tool_grouping.R')
if ( ! identical( lock.name, paste('randomForest_worker_NUM','BER.Rdata', sep='') ) ) {
  set_lock( lock.name )
  set_lock( lock.name2 )
}
load ('norm_data.RData')
no.forests=7
no.trees=433
datRF <- data.frame(data.filtered$z$PCR )
datRF <- data.frame(t(cbind( data.filtered$z$PCR, data.filtered$FACS )))
attach(datRF)
Rf.data <- read_RF ( c('randomForest_worker_genes_0.Rdata', 'randomForest_worker_genes_1.Rdata', 'randomForest_worker_genes_2.Rdata', 'randomForest_worker_genes_3.Rdata', 'randomForest_worker_genes_4.Rdata', 'randomForest_worker_genes_5.Rdata', 'randomForest_worker_genes_6.Rdata', 'randomForest_worker_genes_7.Rdata', 'randomForest_worker_genes_8.Rdata', 'randomForest_worker_genes_9.Rdata', 'randomForest_worker_genes_10.Rdata', 'randomForest_worker_genes_11.Rdata', 'randomForest_worker_genes_12.Rdata', 'randomForest_worker_genes_13.Rdata', 'randomForest_worker_genes_14.Rdata', 'randomForest_worker_genes_15.Rdata', 'randomForest_worker_genes_16.Rdata', 'randomForest_worker_genes_17.Rdata', 'randomForest_worker_genes_18.Rdata', 'randomForest_worker_genes_19.Rdata', 'randomForest_worker_genes_20.Rdata', 'randomForest_worker_genes_21.Rdata', 'randomForest_worker_genes_22.Rdata', 'randomForest_worker_genes_23.Rdata', 'randomForest_worker_genes_24.Rdata', 'randomForest_worker_genes_25.Rdata', 'randomForest_worker_genes_26.Rdata', 'randomForest_worker_genes_27.Rdata', 'randomForest_worker_genes_28.Rdata', 'randomForest_worker_genes_29.Rdata', 'randomForest_worker_genes_30.Rdata', 'randomForest_worker_genes_31.Rdata'),32  )
distRF = RFdist(Rf.data, datRF, no.tree= 433, imp=F)
save( distRF, file="RandomForestdistRFobject_genes.RData" )
